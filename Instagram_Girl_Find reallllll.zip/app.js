/* Independent prank demo. This page does not send or save login form fields.
   Admin credentials are demo-only and visible in page source; do not use for real security. */
(() => {
  const ADMIN_EMAIL = "Vikram@gmail.com";
  const ADMIN_PASSWORD = "1234";
  const $ = (s) => document.querySelector(s);
  const portraits = [
    ["Aarohi","Traditional","Desi-inspired colours and graceful everyday style.","https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=85"],
    ["Meher","Casual","Relaxed fits and soft, sunny-day aesthetics.","https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=85"],
    ["Kiara","Festive","Festive colours and celebration-ready inspiration.","https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=85"],
    ["Sana","Casual","Simple looks with a little golden-hour glow.","https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=800&q=85"],
    ["Ishita","Traditional","Classic-inspired outfits with a modern feel.","https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=85"],
    ["Riya","Festive","Bright palettes and playful festive moodboards.","https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=85"],
    ["Zoya","Casual","Street-style ideas and everyday outfit inspiration.","https://images.unsplash.com/photo-1526510747491-58f928ec870f?auto=format&fit=crop&w=800&q=85"],
    ["Anaya","Traditional","Pastels, patterns and timeless silhouettes.","https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=800&q=85"]
  ];
  let clicks = [], visits = 0, toastTimer;
  const toast = (msg) => { const el=$("#toast"); el.textContent=msg; el.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2600); };
  const showResults = () => {
    // Deliberately do not read, transmit, or store either login field.
    $("#loginView").classList.add("hidden");
    $("#resultsView").classList.remove("hidden");
    $("#reveal").classList.add("hidden");
    visits++;
    window.scrollTo({top:0,behavior:"smooth"});
  };
  $("#loginForm").addEventListener("submit", e => { e.preventDefault(); showResults(); });
  $("#togglePassword").addEventListener("click", () => { const el=$("#password"); el.type=el.type==="password"?"text":"password"; });
  $("#backBtn").addEventListener("click", () => { $("#resultsView").classList.add("hidden"); $("#loginView").classList.remove("hidden"); window.scrollTo({top:0,behavior:"smooth"}); });
  $("#brandLogo").addEventListener("click", e => {
    e.preventDefault(); const now=Date.now(); clicks=clicks.filter(t=>now-t<1700); clicks.push(now);
    if(clicks.length>=5){clicks=[];openAdmin();}
  });
  $("#gallery").innerHTML = portraits.map((p,i)=>`<article class="profile" style="animation-delay:${i*50}ms"><img src="${p[3]}" alt="Desi style inspiration portrait" loading="lazy"><div class="profile-info"><b>${p[0]} · ${p[1]}</b><p>${p[2]}</p><button type="button" data-prank="${i}">View profile ↗</button></div></article>`).join("");
  $("#gallery").addEventListener("click", e => { if(e.target.matches("[data-prank]")) { $("#reveal").classList.remove("hidden"); $("#reveal").scrollIntoView({behavior:"smooth",block:"center"}); } });
  $("#againBtn").addEventListener("click", () => { $("#reveal").classList.add("hidden"); window.scrollTo({top:0,behavior:"smooth"}); });
  function openAdmin(){ $("#adminEmail").value=""; $("#adminPassword").value=""; $("#adminData").classList.add("hidden"); $("#adminForm").classList.remove("hidden"); $("#adminModal").classList.remove("hidden"); }
  function closeAdmin(){ $("#adminModal").classList.add("hidden"); }
  $("#closeAdmin").addEventListener("click",closeAdmin); $("#closeBackdrop").addEventListener("click",closeAdmin);
  $("#adminForm").addEventListener("submit", e=>{
    e.preventDefault();
    if($("#adminEmail").value.trim().toLowerCase()!==ADMIN_EMAIL.toLowerCase() || $("#adminPassword").value!==ADMIN_PASSWORD){toast("Admin details don't match.");return;}
    $("#adminPassword").value="";
    $("#adminForm").classList.add("hidden"); $("#adminData").classList.remove("hidden");
    $("#adminData").innerHTML=`<h3>Local activity</h3><p>Explore page opened ${visits} time(s) in this browser session.</p><p class="safety-note">No visitor number or password is collected or stored. This local counter is not shared across devices.</p><button class="submit" id="doneAdmin">Close dashboard</button>`;
    $("#doneAdmin").addEventListener("click",closeAdmin);
  });
  document.addEventListener("keydown",e=>{if(e.key==="Escape")closeAdmin();});
})();
